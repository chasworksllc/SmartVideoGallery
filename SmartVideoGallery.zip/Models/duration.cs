﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartVideoGallery.Models
{
    public class Duration
    {
        public string time { get; set; }
        public float seconds { get; set; }
    }
}
